function add(a, b) {
    return a + b;
}

function subtract(a, b) {
    return a - b;
}

function multiply(a, b) {
    return a * b;
}

console.log(add(5, 3)); 
console.log(subtract(5, 3)); 
console.log(multiply(5, 3)); 
